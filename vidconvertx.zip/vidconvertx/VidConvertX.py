#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import json
import subprocess
import re
import shlex
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QLineEdit,
                             QHBoxLayout, QPushButton, QListWidget, QFileDialog, 
                             QProgressBar, QMessageBox, QLabel, QComboBox, QGroupBox)
from PyQt6.QtCore import QThread, pyqtSignal, Qt

class FFmpegWorker(QThread):
    """
    Thread responsável por executar o FFmpeg em segundo plano
    para não travar a interface gráfica.
    """
    progress_signal = pyqtSignal(int, str)
    finished_signal = pyqtSignal()
    error_signal = pyqtSignal(str)

    def __init__(self, input_files, output_ext, preset_args, output_dir, special_mode=None):
        super().__init__()
        self.input_files = input_files
        self.output_ext = output_ext
        self.is_running = True
        self.preset_args = preset_args
        self.output_dir = output_dir
        self.special_mode = special_mode

    def get_duration(self, filename):
        """Obtém a duração do vídeo em segundos usando ffprobe."""
        cmd = [
            'ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
            '-of', 'default=noprint_wrappers=1:nokey=1', filename
        ]
        try:
            output = subprocess.check_output(cmd).decode().strip()
            return float(output)
        except Exception:
            return 0.0

    def _get_audio_index(self, filename):
        """Tenta encontrar o índice da trilha de áudio em português ('por')."""
        cmd = [
            'ffprobe', '-v', 'error', '-select_streams', 'a',
            '-show_entries', 'stream=index,codec_type:stream_tags=language',
            '-of', 'json', filename
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            data = json.loads(result.stdout)
            
            audio_streams = [s for s in data.get("streams", []) if s.get("codec_type") == "audio"]
            
            # Procura por 'por'
            for stream in audio_streams:
                if stream.get("tags", {}).get("language", "").lower() == "por":
                    return stream.get("index")

            # Se não achar, retorna o índice da primeira trilha de áudio
            if audio_streams:
                return audio_streams[0].get("index")

        except Exception as e:
            print(f"Aviso: Erro ao detectar trilha de áudio, usando padrão. Detalhe: {e}")
        
        return None

    def _run_target_size_conversion(self, file_index, total_files, input_file, resolution_height):
        """Executa a conversão especial de duas passadas para um tamanho alvo."""
        filename_base = os.path.basename(input_file)
        self.progress_signal.emit(0, f"Analisando ({file_index+1}/{total_files}): {filename_base}")

        duration = self.get_duration(input_file)
        if duration <= 0:
            self.error_signal.emit(f"Não foi possível obter a duração de {filename_base}")
            return False

        audio_index = self._get_audio_index(input_file)
        audio_map_specifier = f"0:{audio_index}" if audio_index is not None else "0:a:0"

        try:
            # (TargetSizeInMB * 8192 / durationInSec) - AudioBitrateInKb
            video_bitrate = int((95 * 8192 / duration) - 96)
            if video_bitrate <= 0:
                self.error_signal.emit(f"Bitrate calculado ({video_bitrate}k) é inválido para {filename_base}")
                return False
        except Exception:
            self.error_signal.emit(f"Erro ao calcular bitrate para {filename_base}")
            return False

        output_filename = f"{os.path.splitext(filename_base)[0]}-100MB-{resolution_height}p.mp4"
        output_file = os.path.join(self.output_dir, output_filename)

        # Define o caminho para os arquivos de log do FFmpeg, para que fiquem na pasta de saída
        log_file_prefix = os.path.join(self.output_dir, "ffmpeg2pass")

        # --- Passo 1 ---
        cmd_pass1 = [
            'ffmpeg', '-y', '-i', input_file,
            '-map', '0:v:0', '-map', audio_map_specifier,
            '-c:v', 'libx264', '-b:v', f'{video_bitrate}k', '-pass', '1', '-passlogfile', log_file_prefix,
            '-preset', 'slow', '-vf', f'scale=-2:{resolution_height}',
            '-an', '-f', 'mp4', os.devnull
        ]

        pass1_success = self._execute_and_monitor(cmd_pass1, duration, f"Passo 1/2 ({file_index+1}/{total_files}): {filename_base}")
        if not pass1_success:
            if self.is_running: # Não mostrar erro se o usuário parou
                self.error_signal.emit(f"Erro no Passo 1 para {filename_base}")
            return False

        if not self.is_running: return False

        # --- Passo 2 ---
        cmd_pass2 = [
            'ffmpeg', '-y', '-i', input_file,
            '-map', '0:v:0', '-map', audio_map_specifier,
            '-c:v', 'libx264', '-b:v', f'{video_bitrate}k', '-pass', '2', '-passlogfile', log_file_prefix,
            '-preset', 'slow', '-vf', f'scale=-2:{resolution_height}',
            '-c:a', 'aac', '-b:a', '96k',
            output_file
        ]
        
        return self._execute_and_monitor(cmd_pass2, duration, f"Passo 2/2 ({file_index+1}/{total_files}): {filename_base} -> {resolution_height}p")

    def _run_standard_conversion(self, file_index, total_files, input_file):
        """Executa a conversão padrão de uma passada."""
        filename_base = os.path.basename(input_file)
        output_filename = os.path.splitext(filename_base)[0] + "_convertido." + self.output_ext
        output_file = os.path.join(self.output_dir, output_filename)
        
        duration = self.get_duration(input_file)
        
        if self.preset_args:
            cmd = ['ffmpeg', '-y', '-i', input_file] + self.preset_args + [output_file]
        else:
            cmd = ['ffmpeg', '-y', '-i', input_file, output_file]

        return self._execute_and_monitor(cmd, duration, f"Convertendo ({file_index+1}/{total_files}): {filename_base}")

    def _execute_and_monitor(self, cmd, duration, status_message):
        """Inicia um processo FFmpeg e monitora seu progresso."""
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, encoding='utf-8', errors='ignore')

        for line in process.stdout:
            if not self.is_running:
                process.terminate()
                process.wait()
                return False
            
            # A expressão regular foi modificada para encontrar a última ocorrência de 'time='
            # em uma linha de buffer, que pode conter várias atualizações de progresso
            # separadas por '\r'. Também foi tornada mais robusta.
            match = re.search(r'.*time=(\d+):(\d{2}):(\d{2})\.\d+', line)
            if match and duration > 0:
                h, m, s = map(int, match.groups())
                current_seconds = h * 3600 + m * 60 + s
                percent = min(100, int((current_seconds / duration) * 100))
                self.progress_signal.emit(percent, status_message)

        process.wait()
        return process.returncode == 0

    def run(self):
        total_files = len(self.input_files)
        try:
            for i, input_file in enumerate(self.input_files):
                if not self.is_running: break

                if self.special_mode == "TARGET_SIZE_720":
                    success = self._run_target_size_conversion(i, total_files, input_file, 720)
                elif self.special_mode == "TARGET_SIZE_480":
                    success = self._run_target_size_conversion(i, total_files, input_file, 480)
                else:
                    success = self._run_standard_conversion(i, total_files, input_file)
                
                if not success and self.is_running:
                    # A mensagem de erro específica já foi emitida pelo método
                    return
            
            if self.is_running:
                self.finished_signal.emit()
        finally:
            # Garante que os arquivos de log sejam sempre limpos ao final da execução (sucesso, erro ou parada).
            for log_file_base in ["ffmpeg2pass-0.log", "ffmpeg2pass-0.log.mbtree"]:
                log_file_path = os.path.join(self.output_dir, log_file_base)
                try:
                    if os.path.exists(log_file_path): os.remove(log_file_path)
                except OSError:
                    pass

    def stop(self):
        self.is_running = False

class VidConvertX(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VidConvertX")
        self.resize(850, 600)
        self.init_presets()
        self.init_ui()
        self.worker = None
        self.files_to_convert = []
        self.output_directory = os.path.expanduser("~")
        self.txt_output_dir.setText(self.output_directory)

    def init_presets(self):
        """Define os presets de conversão para cada formato."""
        self.presets = {
            "mkv": {
                "MKV VP8": "-crf 15.0 -f matroska -b:v 8000k -r 25 -vcodec libvpx -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MKV VP9": "-crf 15.0 -f matroska -b:v 8000k -r 25 -vcodec libvpx-vp9 -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MKV MPEG4": "-crf 15.0 -f matroska -b:v 8000k -r 25 -vcodec mpeg4 -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MKV H265": "-crf 15.0 -f matroska -b:v 8000k -r 25 -vcodec libx265 -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MKV optimized for Youtube": "-c:v libx264 -preset slow -profile:v high -crf 18 -coder 1 -pix_fmt yuv420p -movflags +faststart -g 30 -bf 2 -c:a aac -b:a 384k -profile:a aac_low".split(),
            },
            "avi": {
                "MS Compatible 640x480": "-acodec libmp3lame -vcodec msmpeg4 -b:a 192k -b:v 1000k -s 640x480 -ar 44100".split(),
                "MS Compatible 720x480": "-acodec libmp3lame -vcodec msmpeg4 -b:a 192k -b:v 1000k -s 720x480 -ar 44100".split(),
                "XVID Fullscreen 640x480 (4:3)": "-f avi -r 29.97 -vcodec libxvid -vtag XVID -s 640x480 -aspect 4:3 -maxrate 1800k -b:v 1500k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -bf 2 -flags +4m -cmp 2 -subcmp 2 -g 300 -acodec libmp3lame -ar 48000 -b:a 128k -ac 2".split(),
                "XVID Widescreen 704x384 (16:9)": "-f avi -r 29.97 -vcodec libxvid -vtag XVID -s 704x384 -aspect 16:9 -maxrate 1800k -b:v 1500k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -bf 2 -flags +4m -cmp 2 -subcmp 2 -g 300 -acodec libmp3lame -ar 48000 -b:a 128k -ac 2".split(),
                "AVI optimized for Youtube": "-c:v libx264 -preset slow -profile:v high -crf 18 -coder 1 -pix_fmt yuv420p -movflags +faststart -g 30 -bf 2 -c:a aac -b:a 384k -profile:a aac_low".split(),
            },
            "mpg": {
                "DVD Fullscreen 352x480 (4:3)": "-f dvd -target ntsc-dvd -vcodec mpeg2video -r 29.97 -s 352x480 -aspect 4:3 -b:v 4000k -mbd rd -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "DVD Widescreen 352x480 (16:9)": "-f dvd -target ntsc-dvd -vcodec mpeg2video -r 29.97 -s 352x480 -aspect 16:9 -b:v 4000k -mbd rd -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "DVD Fullscreen 720x480 (4:3) High Quality": "-f dvd -target ntsc-dvd -r 29.97 -s 720x480 -aspect 4:3 -b:v 8000k -mbd rd -cmp 0 -subcmp 2".split(),
                "DVD Widescreen 720x480 (16:9) High Quality": "-f dvd -target ntsc-dvd -r 29.97 -s 720x480 -aspect 16:9 -b:v 8000k -g 12 -mbd rd -cmp 0 -subcmp 2".split(),
                "DVD Low Quality 720x480": "-f dvd -target ntsc-dvd -b:v 5000k -r 29.97 -s 720x480 -ar 48000 -b:a 384k".split(),
                "NTSC VCD High Quality": "-f vcd -target ntsc-vcd -mbd rd -cmp 0 -subcmp 2".split(),
                "PAL VCD High Quality": "-f vcd -target pal-vcd -mbd rd -trellis -mv0 -cmp 0 -subcmp 2".split(),
                "RB Toshiba Gigabeat F/X": "-acodec libmp3lame -b:a 128k -ar 44100 -vcodec mpeg2video -b:v 600k -strict -1".split(),
                "RB Apple iPod Video": "-acodec libmp3lame -b:a 128k -ar 44100 -vcodec mpeg2video -b:v 400k -strict -1".split(),
                "NTSC DVD Fullscreen": "-f dvd -vcodec mpeg2video -r 30000/1001 -aspect 4:3 -b:v 4000k -mbd rd -trellis 1 -flags +mv0 -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "NTSC DVD Widescreen": "-f dvd -vcodec mpeg2video -r 30000/1001 -aspect 16:9 -b:v 4000k -mbd rd -trellis 1 -flags +mv0 -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "NTSC DVD HQ Fullscreen": "-f dvd -target ntsc-dvd -r 30000/1001 -aspect 4:3 -vb 8000k -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
                "NTSC DVD HQ Widescreen": "-f dvd -target ntsc-dvd -r 30000/1001 -aspect 16:9 -vb 8000k -g 12 -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
                "NTSC DVD Fast (LQ)": "-f dvd -target ntsc-dvd -b:v 5000k -r 30000/1001 -ar 48000 -b:a 384k".split(),
                "NTSC VCD (HQ)": "-f vcd -target ntsc-vcd -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
                "PAL DVD Fullscreen": "-f dvd -vcodec mpeg2video -r 25.00 -aspect 4:3 -b:v 4000k -mbd rd -trellis 1 -flags +mv0 -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "PAL DVD Widescreen": "-f dvd -vcodec mpeg2video -r 25.00 -aspect 16:9 -b:v 4000k -mbd rd -trellis 1 -flags +mv0 -cmp 2 -subcmp 2 -acodec mp2 -b:a 192k -ar 48000 -ac 2".split(),
                "PAL DVD HQ Fullscreen": "-f dvd -target pal-dvd -aspect 4:3 -vb 8000k -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
                "PAL DVD HQ Widescreen": "-f dvd -target pal-dvd -aspect 16:9 -vb 8000k -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
                "PAL DVD Fast (LQ)": "-f dvd -target pal-dvd -b:v 5000k -r 25 -ar 48000 -b:a 384k".split(),
                "PAL VCD (HQ)": "-f vcd -target pal-vcd -mbd rd -trellis 1 -flags +mv0 -cmp 0 -subcmp 2".split(),
            },
            "flv": {
                "Flash Video (flv) for Web use Fullscreen": "-vcodec flv -f flv -r 29.97 -aspect 4:3 -b:v 300k -g 160 -cmp dct  -subcmp dct  -mbd 2 -trellis 1 -ac 1 -ar 22050 -b:a 56k".split(),
                "Flash Video (flv) for Web use Widescreen": "-vcodec flv -f flv -r 29.97 -aspect 16:9 -b:v 300k -g 160 -cmp dct -subcmp dct -mbd 2 -trellis 1 -ac 1 -ar 22050 -b:a 56k".split(),
            },
            "mp4": {
                "MP4 High Quality": "-crf 35.0 -vcodec libx264 -acodec aac -ar 48000 -b:a 128k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MP4 Very High Quality": "-crf 25.0 -vcodec libx264 -acodec aac -ar 48000 -b:a 160k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MP4 Super High Quality": "-crf 15.0 -vcodec libx264 -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp +chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1 -strict -2".split(),
                "MP4 Fullscreen (4:3)": "-f mp4 -r 29.97 -vcodec libx264 -s 640x480 -b:v 1000k -aspect 4:3 -flags +loop -cmp +chroma -maxrate 1500k -bufsize 4M -bt 256k -refs 1 -bf 3 -coder 1 -me_method umh -me_range 16 -subq 7 -partitions +parti4x4+parti8x8+partp8x8+partb8x8 -g 250 -keyint_min 25 -level 30 -qmin 10 -qmax 51 -qcomp 0.6 -sc_threshold 40 -i_qfactor 0.71 -acodec aac -b:a 112k -ar 48000 -ac 2 -strict -2".split(),
                "MP4 Widescreen (16:9)": "-f mp4 -r 29.97 -vcodec libx264 -s 704x384 -b:v 1000k -aspect 16:9 -flags +loop -cmp +chroma -maxrate 1500k -bufsize 4M -bt 256k -refs 1 -bf 3 -coder 1 -me_method umh -me_range 16 -subq 7 -partitions +parti4x4+parti8x8+partp8x8+partb8x8 -g 250 -keyint_min 25 -level 30 -qmin 10 -qmax 51 -qcomp 0.6 -trellis 2 -sc_threshold 40 -i_qfactor 0.71 -acodec aac -b:a 112k -ar 48000 -ac 2 -strict -2".split(),
                "MP4 H.265 Fullscreen (4:3) High Compression": "-c:v libx265 -preset medium -crf 28 -s 640x480 -c:a aac -b:a 128k -strict -2".split(),
                "MP4 H.265 Widescreen (16:9) High Compression": "-c:v libx265 -preset medium -crf 28 -s 704x384 -c:a aac -b:a 128k -strict -2".split(),
				"MP4 H.264 Widescreen (16:9) High Compression": "-c:v libx264 -preset medium -crf 28 -c:a aac -b:a 128k -strict -2".split(),
                "MP4 H.265 Not Resizing High Compression": "-c:v libx265 -preset medium -crf 28  -c:a aac -b:a 128k -strict -2".split(),
                "MP4 optimized for Youtube": "-c:v libx264 -preset slow -profile:v high -crf 18 -coder 1 -pix_fmt yuv420p -movflags +faststart -g 30 -bf 2 -c:a aac -b:a 384k -profile:a aac_low".split(),
                "Blackberry Curve Fullscreen": "-f mp4 -vcodec mpeg4 -b:v 400k -r 24 -aspect 4:3 -acodec aac -ar 22050 -ac 2 -b:a 48k".split(),
                "Blackberry Curve Widescreen": "-f mp4 -vcodec mpeg4 -b:v 400k -r 24 -aspect 16:9 -acodec aac -ar 22050 -ac 2 -b:a 48k".split(),
                "Neuros HQ NTSC Fullscreen": "-f mp4 -r 29.97 -vcodec libxvid -aspect 4:3 -maxrate 2500k -b:v 2000k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -trellis 1 -flags +aic -cmp 2 -subcmp 2 -g 300 -acodec aac -ar 48000 -b:a 128k -ac 2".split(),
                "Neuros HQ PAL Fullscreen": "-f mp4 -r 25 -vcodec libxvid -aspect 4:3 -maxrate 2500k -b:v 2000k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -trellis 1 -flags +aic -cmp 2 -subcmp 2 -g 300 -acodec aac -ar 48000 -b:a 128k -ac 2".split(),
                "Neuros Small File NTSC Fullscreen": "-f mp4 -b:v 800k -r 29.97 -aspect 4:3 -vcodec libxvid -ar 48000 -b:a 80k -ac 2 -acodec aac".split(),
                "Neuros Small File PAL Fullscreen": "-f mp4 -b:v 800k -r 25 -aspect 4:3 -vcodec libxvid -ar 48000 -b:a 80k -ac 2 -acodec aac".split(),
                "Neuros HQ NTSC Widescreen": "-f mp4 -r 29.97 -vcodec libxvid -aspect 16:9 -maxrate 3000k -b:v 2500k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -bf 2 -trellis 1 -flags +aic -cmp 2 -subcmp 2 -g 300 -acodec aac -ar 48000 -b:a 128k -ac 2".split(),
                "Neuros HQ PAL Widescreen": "-f mp4 -r 25 -vcodec libxvid -aspect 16:9 -maxrate 3000k -b:v 2500k -qmin 3 -qmax 5 -bufsize 4096 -mbd 2 -bf 2 -trellis 1 -flags +aic -cmp 2 -subcmp 2 -g 300 -acodec aac -ar 48000 -b:a 128k -ac 2".split(),
                "Neuros Small File NTSC Widescreen": "-f mp4 -b:v 800k -r 29.97 -aspect 16:9 -vcodec libxvid -ar 48000 -b:a 80k -ac 2 -acodec aac".split(),
                "Neuros Small File PAL Widescreen": "-f mp4 -b:v 800k -r 25 -aspect 16:9 -vcodec libxvid -ar 48000 -b:a 80k -ac 2 -acodec aac".split(),
                "Converter (~100MB, 720p)": "SPECIAL_TARGET_SIZE_720",
                "Converter (~100MB, 480p)": "SPECIAL_TARGET_SIZE_480",
            },
            "webm": {
                "WEBM VP8 Fullscreen (4:3)": "-f webm -aspect 4:3 -vcodec libvpx -g 120 -level 216 -profile:v 0 -qmax 42 -qmin 10 -rc_buf_aggressivity 0.95 -vb 2M -acodec libvorbis -aq 90 -ac 2".split(),
                "WEBM VP8 Widescreen (16:9)": "-f webm -aspect 16:9 -vcodec libvpx -g 120 -level 216 -profile:v 0 -qmax 42 -qmin 10 -rc_buf_aggressivity 0.95 -vb 2M -acodec libvorbis -aq 90 -ac 2".split(),
                "WEBM VP9 Fullscreen (4:3)": "-f webm -aspect 4:3 -vcodec libvpx-vp9 -b:v 1M -acodec libvorbis".split(),
                "WEBM VP9 Widescreen (16:9)": "-f webm -aspect 16:9 -vcodec libvpx-vp9 -b:v 1M -acodec libvorbis".split(),
            },
            "wmv": {
                "WMV Generic": "-vcodec wmv2 -acodec wmav2 -b:v 1000k -b:a 160k -r 25".split(),
                "WMV for Web Use": "-vcodec wmv2 -acodec wmav2 -b:v 640k -b:a 128k -r 29.97 -ac 2".split(),
                "Xbox 360": "-vcodec wmv2 -acodec wmav2 -b:v 1200k -b:a 160k -r 25 -ac 2".split(),
                "Zune": "-vcodec wmv2 -acodec wmav2 -b:v 640k -b:a 128k -r 23.97 -ac 2".split(),
                "Power Point": "-vcodec wmv2 -acodec wmav2 -aspect 4:3 -b:v 500k -b:a 32k -ac 1 -ar 22050 -ac 2".split(),
            },
            "ogv": {
                "OGV Generic": "-c:v libtheora -q:v 7 -c:a libvorbis -q:a 4".split(),
            },
            "mp3": {
                "Extract Audio mp3": "-q:a 0 -map a -vn".split(),
                "Optimized mp3": "-c:a libmp3lame -joint_stereo 1 -abr 1 -b:a 128k -vn".split(),
                "MP3 Good Quality (160 Kbps)": "-acodec libmp3lame -ab 160k -ac 2 -ar 44100 -vn".split(),
                "MP3 High Quality (192 Kbps)": "-acodec libmp3lame -ab 192k -ac 2 -ar 44100 -vn".split(),
                "MP3 lame VBR-preset 2 (good-standard 170-210k)": "-aq 2 -acodec libmp3lame -vn".split(),
            },
            "m4a": {
                "Extract audio aac": "-acodec copy".split(),
                "Extract audio stream and remux to m4a": "-vn -acodec copy".split(),
                "MPEG4 Audio": "-vn -acodec aac -b:a 112k -ac 2 -ar 48000".split(),
            },
            "ogg": {
                "OGG (libvorbis)": "-acodec libvorbis -vn -ac 2".split(),
                "OGG Mono (libvorbis)": "-acodec libvorbis -vn -ac 1".split(),
            },
            "flac": {
                "Free Lossless Audio Codec - Auto": "-acodec flac -vn".split(),
            },
            "ac3": {
                "Ac3 DVD - 192kbps Stereo": "-f ac3 -acodec ac3 -ab 192kb -ar 48000 -ac 2".split(),
                "Ac3 DVD - 384kbps Stereo": "-f ac3 -acodec ac3 -ab 384kb -ar 48000 -ac 2".split(),
            },
            "aiff": {
                "Audio Interchange File - Auto": "-vn".split(),
            },
            "asf": {
                "Active Streaming Format - Auto": "-vcodec msmpeg4".split(),
            },
            "rm": {
                "RealVideo 1.0": "-ar 44100 -ab 128kb -vcodec rv10".split(),
                "RealVideo 2.0": "-ar 44100 -ab 128kb -vcodec rv20".split(),
            },
            "au": {
                "Sun Audio - Auto": "-vn".split(),
            },
            "mp2": {
                "MPEG-1 Audio Layer II  - Auto": "-acodec mp2 -vn".split(),
            },
            "wma": {
                "WMA": "-vn -acodec wmav2 -b:a 160k -ac 2".split(),
            },
            "wav": {
                "Wav for CD": "-vn -ar 44100".split(),
            },
            "3g2": {
                "CDMA Phone Audio (3g2)": "-f 3g2 -ar 22050 -b:a 128k -acodec aac -r 14.985 -vn".split(),
            },
            "3gp": {
                "3GPP H.264 AAC mono": "-r 15 -b:v 64k -ac 1 -ar 16000 -b:a 32k -acodec aac -vcodec libx264".split(),
                "3GPP H.264 AAC stereo": "-r 15 -b:v 128k -ar 22050 -b:a 64k -acodec aac -vcodec libx264 -preset medium -coder 1 -flags +loop -cmp chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1".split(),
            },
            "dv": {
                "Raw DV for NTSC Fullscreen": "-target ntsc-dv -aspect 4:3 -f dv".split(),
                "Raw DV for PAL Fullscreen": "-target pal-dv -aspect 4:3 -f dv".split(),
            },
            "mov": {
                "MOV Generic": "-acodec aac -vcodec libx264 -f mov".split(),
                "QuickTime H.264 video (High Quality)": "-crf 35.0 -vcodec libx264 -preset slow -acodec aac -ar 48000 -b:a 128k -coder 1 -flags +loop -cmp chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1".split(),
                "QuickTime H.264 video (Super High Quality)": "-crf 15.0 -vcodec libx264 -preset veryslow -acodec aac -ar 48000 -b:a 192k -coder 1 -flags +loop -cmp chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1".split(),
                "QuickTime H.264 video (Very High Quality)": "-crf 25.0 -vcodec libx264 -preset slower -acodec aac -ar 48000 -b:a 160k -coder 1 -flags +loop -cmp chroma -partitions +parti4x4+partp8x8+partb8x8 -me_method hex -subq 6 -me_range 16 -g 250 -keyint_min 25 -sc_threshold 40 -i_qfactor 0.71 -b_strategy 1".split(),
                "MOV optimized for Youtube": "-c:v libx264 -preset slow -profile:v high -crf 18 -coder 1 -pix_fmt yuv420p -movflags +faststart -g 30 -bf 2 -c:a aac -b:a 384k -profile:a aac_low".split(),
            },
        }

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # --- Lista de Arquivos ---
        group_files = QGroupBox("Arquivos de Entrada")
        layout_files = QVBoxLayout()
        self.list_widget = QListWidget()
        layout_files.addWidget(self.list_widget)
        
        btn_layout = QHBoxLayout()
        self.btn_add = QPushButton("Adicionar Arquivos")
        self.btn_add.clicked.connect(self.add_files)
        self.btn_clear = QPushButton("Limpar Lista")
        self.btn_clear.clicked.connect(self.clear_list)
        
        btn_layout.addWidget(self.btn_add)
        btn_layout.addWidget(self.btn_clear)
        layout_files.addLayout(btn_layout)
        group_files.setLayout(layout_files)
        main_layout.addWidget(group_files)

        # --- Opções de Conversão ---
        group_opts = QGroupBox("Opções de Saída")
        layout_opts = QHBoxLayout()
        layout_opts.addWidget(QLabel("Formato:"))
        self.combo_format = QComboBox()
        
        self.combo_format.addItems(sorted(self.presets.keys()))
        self.combo_format.currentTextChanged.connect(self.update_presets)
        layout_opts.addWidget(self.combo_format)

        layout_opts.addWidget(QLabel("Qualidade:"))
        self.combo_preset = QComboBox()
        layout_opts.addWidget(self.combo_preset)

        group_opts.setLayout(layout_opts)
        main_layout.addWidget(group_opts)

        # --- Pasta de Saída ---
        group_path = QGroupBox("Pasta de Saída")
        layout_path = QHBoxLayout()
        self.txt_output_dir = QLineEdit()
        self.txt_output_dir.setReadOnly(True)
        self.btn_browse_output = QPushButton("Selecionar...")
        self.btn_browse_output.clicked.connect(self.select_output_directory)
        layout_path.addWidget(self.txt_output_dir)
        layout_path.addWidget(self.btn_browse_output)
        group_path.setLayout(layout_path)
        main_layout.addWidget(group_path)

        # --- Progresso e Ações ---
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        main_layout.addWidget(self.progress_bar)

        self.lbl_status = QLabel("Pronto. Adicione arquivos para começar.")
        main_layout.addWidget(self.lbl_status)

        action_layout = QHBoxLayout()
        self.btn_start = QPushButton("Iniciar Conversão")
        self.btn_start.clicked.connect(self.start_conversion)
        self.btn_stop = QPushButton("Parar")
        self.btn_stop.clicked.connect(self.stop_conversion)
        self.btn_stop.setEnabled(False)

        action_layout.addWidget(self.btn_start)
        action_layout.addWidget(self.btn_stop)
        main_layout.addLayout(action_layout)

        # Popula os presets iniciais
        self.update_presets(self.combo_format.currentText())

    def update_presets(self, format_text):
        """Atualiza a lista de presets com base no formato selecionado."""
        self.combo_preset.clear()
        if format_text in self.presets:
            self.combo_preset.addItems(self.presets[format_text].keys())
            self.combo_preset.setEnabled(True)
        else:
            self.combo_preset.setEnabled(False)

    def select_output_directory(self):
        """Abre um diálogo para selecionar a pasta de destino."""
        directory = QFileDialog.getExistingDirectory(self, "Selecionar Pasta de Saída", self.output_directory)
        if directory:
            self.output_directory = directory
            self.txt_output_dir.setText(self.output_directory)

    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Selecionar Arquivos Multimídia")
        if files:
            self.files_to_convert.extend(files)
            for f in files:
                self.list_widget.addItem(f)
            self.lbl_status.setText(f"{len(self.files_to_convert)} arquivos na fila.")

    def clear_list(self):
        self.files_to_convert.clear()
        self.list_widget.clear()
        self.lbl_status.setText("Lista limpa.")
        self.progress_bar.setValue(0)

    def start_conversion(self):
        if not self.files_to_convert:
            QMessageBox.warning(self, "Aviso", "Adicione arquivos para converter primeiro.")
            return

        if not self.output_directory or not os.path.isdir(self.output_directory):
            QMessageBox.warning(self, "Aviso", "Por favor, selecione uma pasta de saída válida.")
            return

        ext = self.combo_format.currentText()
        preset_name = self.combo_preset.currentText()
        special_mode = None
        
        preset_args = []
        if ext in self.presets and preset_name in self.presets[ext]:
            preset_value = self.presets[ext][preset_name]
            if preset_value == "SPECIAL_TARGET_SIZE_720":
                special_mode = "TARGET_SIZE_720"
            elif preset_value == "SPECIAL_TARGET_SIZE_480":
                special_mode = "TARGET_SIZE_480"
            else:
                preset_args = preset_value
        
        self.worker = FFmpegWorker(self.files_to_convert, ext, preset_args, self.output_directory, special_mode)
        self.worker.progress_signal.connect(self.update_progress)
        self.worker.finished_signal.connect(self.conversion_finished)
        self.worker.error_signal.connect(self.conversion_error)
        
        self.worker.start()
        
        self.btn_start.setEnabled(False)
        self.btn_add.setEnabled(False)
        self.btn_clear.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.lbl_status.setText("Iniciando conversão...")

    def stop_conversion(self):
        if self.worker:
            self.worker.stop()
            self.lbl_status.setText("Parando...")

    def update_progress(self, val, msg):
        self.progress_bar.setValue(val)
        self.lbl_status.setText(msg)

    def conversion_finished(self):
        self.lbl_status.setText("Conversão Concluída!")
        self.progress_bar.setValue(100)
        QMessageBox.information(self, "Sucesso", "Todas as tarefas foram concluídas.")
        self.reset_ui()

    def conversion_error(self, err_msg):
        self.lbl_status.setText(f"Erro: {err_msg}")
        QMessageBox.critical(self, "Erro", err_msg)
        self.reset_ui()

    def reset_ui(self):
        self.btn_start.setEnabled(True)
        self.btn_add.setEnabled(True)
        self.btn_clear.setEnabled(True)
        self.btn_stop.setEnabled(False)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VidConvertX()
    window.show()
    sys.exit(app.exec())